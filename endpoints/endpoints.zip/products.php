<?php

require_once "api_config.php";
echo json_encode($db->maestro_productos());