<?php

header('content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
$email = isset($_REQUEST["email"]) ? $_REQUEST["email"] : "";
$pw = isset($_REQUEST["password"]) ? $_REQUEST["password"] : "";
$real = md5("adiel@dccolorweb.com-adiel123");
$to_check = md5($email . "-". $pw);

if ( $real == $to_check ) {
	include "user_login.json";
} else {
	include "user_login_error.json";
}